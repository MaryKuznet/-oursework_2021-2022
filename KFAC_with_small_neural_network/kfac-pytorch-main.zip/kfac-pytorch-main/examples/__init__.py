"""KFAC Example Scripts."""
from __future__ import annotations
