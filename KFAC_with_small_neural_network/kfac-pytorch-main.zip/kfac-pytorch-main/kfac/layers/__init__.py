"""KFAC layer approximation module."""
from __future__ import annotations
